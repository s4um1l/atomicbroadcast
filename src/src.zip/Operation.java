
public class Operation {
 public Operation(int i, int parseInt) {
	 type=i;
	 data=parseInt;
		// TODO Auto-generated constructor stub
	}
 public Operation( ) {
		// TODO Auto-generated constructor stub
	}
int type;//0 for push  1 for pop
 int  data;// has input data  or outpus the data popped
}
