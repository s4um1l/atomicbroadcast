
public class ParticipatingNode{
	int id;
	String Name;
	int port;
	public ParticipatingNode(String Name,int port,int id){
		this.Name=Name;
		this.port=port;
		this.id=id;
	}
	
}